//
//  ViewController.swift
//  Vobilishetty_Calculator
//
//  Created by Vobilishetty,Praneeth Kumar on 2/13/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var resultlabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func allClearButton(_ sender: UIButton) {
    }
    
    
    @IBAction func clearButton(_ sender: UIButton) {
    }
    
    
    @IBAction func PlusMinusButton(_ sender: UIButton) {
    }
    
    
    @IBAction func multiplyButton(_ sender: UIButton) {
    }
    
    @IBAction func sevenButton(_ sender: UIButton) {
    }
    
    
    @IBAction func eightButton(_ sender: UIButton) {
    }
    
    
    @IBAction func nineButton(_ sender: UIButton) {
    }
    
    @IBAction func plusButton(_ sender: UIButton) {
    }
    
    
    @IBAction func fourButton(_ sender: UIButton) {
    }
    
    @IBAction func fiveButton(_ sender: UIButton) {
    }
    
    @IBAction func sixButton(_ sender: UIButton) {
    }
    
    
    @IBAction func minusButton(_ sender: UIButton) {
    }
    
    
    @IBAction func threeButton(_ sender: UIButton) {
    }
    
    
    @IBAction func twoButton(_ sender: UIButton) {
    }
    
    
    @IBAction func oneButton(_ sender: UIButton) {
    }
    
    @IBAction func divideButton(_ sender: UIButton) {
    }
    
    
    @IBAction func zeroButton(_ sender: UIButton) {
    }
    
    
    @IBAction func pointButton(_ sender: UIButton) {
    }
    
    
    @IBAction func percentageButton(_ sender: UIButton) {
    }
    
    @IBAction func calculateButton(_ sender: UIButton) {
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

